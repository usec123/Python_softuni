import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import *

def create_pet(name: str, species: str):
    Pet.objects.create(name=name,species=species)
    return f"{name} is a very cute {species}!"

def create_artifact(name: str, origin: str, age: int, description: str, is_magical: bool):
    Artifact.objects.create(name=name,origin=origin,age=age,description=description,is_magical=is_magical)
    return f"The artifact {name} is {age} years old!"

def rename_artifact(artifact: Artifact, new_name: str):
    if artifact.is_magical and artifact.age > 250:
        artifact.name = new_name
        artifact.save()

def delete_all_artifacts():
    Artifact.objects.all().delete()
    
def show_all_locations() -> str:
    return '\n'.join([f'{l.name} has a population of {l.population}!' for l in Location.objects.all().order_by('id')[::-1]])

def new_capital() -> None:
    first_location = Location.objects.first()
    first_location.is_capital = True
    first_location.save()

def get_capitals():
    return Location.objects.all().filter(is_capital=True).values('name')

def delete_first_location():
    Location.objects.first().delete()

# Create queries within functions

# [print(create_pet(name,species)) for name,species in zip(
#     ['Buddy', 'Whiskers', 'Rocky'],
#     ['Dog', 'Cat', 'Hamster']
# )]

# print(create_artifact('Ancient Sword', 'Lost Kingdom', 500, 'A legendary sword with a rich history', True))
# artifact_object = Artifact.objects.get(name='Ancient Sword')
# rename_artifact(artifact_object, 'Ancient Shield')
# print(artifact_object.name)

# for name, region, population, description, is_capital in zip(
#     ['Sofia', 'Plovdiv', 'Varna'],
#     ['Sofia Region', 'Plovdiv Region', 'Varna Region'],
#     [1329000, 346942, 330486],
#     ['The capital of Bulgaria and the largest city in the country', 'The second-largest city in Bulgaria with a rich historical heritage', 'A city known for its sea breeze and beautiful beaches on the Black Sea'],
#     [False, False, False]
# ):
#     location = Location()
#     location.name = name
#     location.region = region
#     location.population = population
#     location.description = description
#     location.is_capital = is_capital
#     location.save()

# print(show_all_locations())
# print(new_capital())
# print(get_capitals())
