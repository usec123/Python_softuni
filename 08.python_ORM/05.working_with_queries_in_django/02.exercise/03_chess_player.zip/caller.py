import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models
from main_app.models import *

# Create and check models
def show_highest_rated_art() -> str:
    top = ArtworkGallery.objects.order_by('-rating', 'id').first()
    return f'{top.art_name} is the highest-rated art with a {top.rating} rating!'

def bulk_create_arts(first_art: ArtworkGallery, second_art: ArtworkGallery):
    ArtworkGallery.objects.bulk_create([first_art, second_art])

def delete_negative_rated_arts():
    ArtworkGallery.objects.filter(rating__lt=0).delete()

def show_the_most_expensive_laptop() -> str:
    laptop = Laptop.objects.order_by('-price', '-id').first()
    return f'{laptop.brand} is the most expensive laptop available for {laptop.price}$!'

def bulk_create_laptops(args):
    Laptop.objects.bulk_create(args)

def update_to_512_GB_storage():
    Laptop.objects.filter(brand__in=('Asus', 'Lenovo')).update(storage=512)

def update_to_16_GB_memory():
    Laptop.objects.filter(brand__in=('Apple', 'Dell', 'Acer')).update(memory=16)

def update_operation_systems():
    Laptop.objects.filter(brand='Asus').update(operation_system=OSChoices.WINDOWS)
    Laptop.objects.filter(brand='Apple').update(operation_system=OSChoices.MACOS)
    Laptop.objects.filter(brand__in=('Dell', 'Acer')).update(operation_system=OSChoices.LINUX)
    Laptop.objects.filter(brand='Lenovo').update(operation_system=OSChoices.CHROME_OS)

def delete_inexpensive_laptops():
    Laptop.objects.filter(price__lt=1200).delete()

def bulk_create_chess_players(args):
    ChessPlayer.objects.bulk_create(args)

def delete_chess_players():
    ChessPlayer.objects.filter(title='no title').delete()

def change_chess_games_won():
    ChessPlayer.objects.filter(title='GM').update(games_won=30)

def change_chess_games_lost():
    ChessPlayer.objects.filter(title='no title').update(games_lost=25)

def change_chess_games_drawn():
    ChessPlayer.objects.all().update(games_drawn=10)

def grand_chess_title_GM():
    ChessPlayer.objects.filter(rating__gte=2400).update(title='GM')

def grand_chess_title_IM():
    ChessPlayer.objects.filter(rating__range=(2300, 2399)).update(title='IM')
    
def grand_chess_title_FM():
    ChessPlayer.objects.filter(rating__range=(2200, 2299)).update(title='FM')
    
def grand_chess_title_regular_player():
    ChessPlayer.objects.filter(rating__range=(0, 2199)).update(title='regular player')
    
    

# Run and print your queries
# artwork1 = ArtworkGallery(artist_name='Vincent van Gogh', art_name='Starry Night', rating=4, price=1200000.0)
# artwork2 = ArtworkGallery(artist_name='Leonardo da Vinci', art_name='Mona Lisa', rating=5, price=1500000.0)
# Bulk saves the instances
# bulk_create_arts(artwork1, artwork2)
# print(show_highest_rated_art())
# print(ArtworkGallery.objects.all())

# laptop1 = Laptop(brand='Asus',processor='Intel Core i5',memory=8, storage=256, operation_system='MacOS', price=899.99 )
# laptop2 = Laptop( brand='Apple', processor='Chrome OS', memory=16, storage=256, operation_system='MacOS', price=1399.99 )
# laptop3 = Laptop( brand='Lenovo', processor='AMD Ryzen 7', memory=12, storage=256, operation_system='Linux', price=999.99, )

# # # Create a list of instances
# laptops_to_create = [laptop1, laptop2, laptop3]

# # # Use bulk_create to save the instances
# bulk_create_laptops(laptops_to_create)
# update_to_512_GB_storage()
# update_operation_systems()

# # # Retrieve 2 laptops from the database
# asus_laptop = Laptop.objects.filter(brand__exact='Asus').get()
# lenovo_laptop = Laptop.objects.filter(brand__exact='Lenovo').get()
# print(asus_laptop.storage)
# print(lenovo_laptop.operation_system)
