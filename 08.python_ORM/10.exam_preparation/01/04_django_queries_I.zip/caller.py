import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Director, Actor
from django.db.models import Q, F, Count, Avg

# Create queries within functions
# print(Director.objects.get_directors_by_movies_count())

def get_directors(search_name:str|None=None, search_nationality:str|None=None):
    res = ''
    if search_name and search_nationality:
        res = Director.objects.filter(full_name__contains=search_name, nationality__contains=search_nationality)
    
    elif not search_name and not search_nationality:
        res = ''
    
    else:
        if search_name:
            res = Director.objects.filter(full_name__icontains=search_name)
        else:
            res = Director.objects.filter(nationality__icontains=search_nationality)
    
    if res:
        res = res.order_by('full_name')
        return '\n'.join(
            f'Director: {director.full_name}, nationality: {director.nationality}, experience: {director.years_of_experience}' for director in res
        )
    return ''

def get_top_director():
    res = Director.objects.get_directors_by_movies_count().first()
    if res:
        return f"Top Director: {res.full_name}, movies: {res.movies_count}."
    else: return ''

def get_top_actor():
    res = Actor.objects\
            .prefetch_related('starring_movies')\
            .annotate(movies_count = Count('starring_movies'), average_rating = Avg('starring_movies__rating'))\
            .order_by('-movies_count', 'full_name')\
            .first()
    if res:
        if res.movies_count:
            avg = f'{res.average_rating:.1f}'
            return f'Top Actor: {res.full_name}, starring in movies: {", ".join(m.title for m in res.starring_movies.all() if m)}, movies average rating: {avg}'
    return ''

# print(get_top_actor())
