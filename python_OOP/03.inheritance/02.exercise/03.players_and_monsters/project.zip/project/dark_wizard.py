from .wizard import Wizard


class DarkWizard(Wizard):
    pass
