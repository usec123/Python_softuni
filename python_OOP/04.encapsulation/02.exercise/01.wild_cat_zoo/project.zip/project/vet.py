from .worker import Worker


class Vet(Worker):
    pass
