from .food import Food


class MainDish(Food):
    pass
